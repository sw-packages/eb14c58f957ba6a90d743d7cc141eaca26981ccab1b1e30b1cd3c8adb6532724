#pragma once

#ifdef CMAKE_BUILD
#  include <pango_training_export.h>
#endif
